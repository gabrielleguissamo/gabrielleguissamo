import { useState } from 'react'
import { Plus, X, TrendingUp, Calendar, DollarSign, AlertCircle } from 'lucide-react'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'
import { Badge } from '../../components/ui/Badge'

const mockTransactions = [
  { date: '02/06/2026', patient: 'Ana Lima', type: 'Sessão', amount: 180, status: 'pago' as const },
  { date: '02/06/2026', patient: 'Pedro Santos', type: 'Sessão', amount: 180, status: 'pendente' as const },
  { date: '01/06/2026', patient: 'Mariana Costa', type: 'Avaliação', amount: 350, status: 'pago' as const },
  { date: '30/05/2026', patient: 'João Oliveira', type: 'Sessão', amount: 200, status: 'cancelado' as const },
  { date: '29/05/2026', patient: 'Clara Ferreira', type: 'Sessão', amount: 180, status: 'pago' as const },
  { date: '28/05/2026', patient: 'Lucas Mendes', type: 'Material', amount: 50, status: 'pago' as const },
]

const statusVariant = { pago: 'success' as const, pendente: 'warning' as const, cancelado: 'danger' as const }
const statusLabel = { pago: 'Pago', pendente: 'Pendente', cancelado: 'Cancelado' }

const metrics = [
  { label: 'Receita do mês', value: 'R$ 4.320,00', icon: TrendingUp, color: 'text-green-500' },
  { label: 'Sessões realizadas', value: '24', icon: Calendar, color: 'text-blue-500' },
  { label: 'Ticket médio', value: 'R$ 180,00', icon: DollarSign, color: 'text-green-400' },
  { label: 'Inadimplência', value: 'R$ 360,00', icon: AlertCircle, color: 'text-orange-400' },
]

export function Financeiro() {
  const [showModal, setShowModal] = useState(false)

  return (
    <div className="p-6 space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {metrics.map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-ink-4">{label}</span>
              <Icon className={`w-5 h-5 ${color}`} />
            </div>
            <p className="font-serif text-2xl font-semibold text-ink">{value}</p>
          </Card>
        ))}
      </div>

      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex gap-3">
            <select className="h-10 px-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500">
              <option>Junho 2026</option><option>Maio 2026</option><option>Abril 2026</option>
            </select>
            <select className="h-10 px-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500">
              <option>Todos os status</option><option>Pago</option><option>Pendente</option><option>Cancelado</option>
            </select>
          </div>
          <Button onClick={() => setShowModal(true)}>
            <Plus className="w-4 h-4" /> Novo lançamento
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-ink-4 border-b border-gray-100">
                <th className="pb-3 font-medium">Data</th>
                <th className="pb-3 font-medium">Paciente</th>
                <th className="pb-3 font-medium">Tipo</th>
                <th className="pb-3 font-medium">Valor</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {mockTransactions.map((t, i) => (
                <tr key={i}>
                  <td className="py-3 text-ink-4">{t.date}</td>
                  <td className="py-3 text-ink font-medium">{t.patient}</td>
                  <td className="py-3 text-ink-3">{t.type}</td>
                  <td className="py-3 font-medium text-ink">R$ {t.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                  <td className="py-3"><Badge variant={statusVariant[t.status]}>{statusLabel[t.status]}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-serif text-lg font-semibold">Novo lançamento</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5 text-ink-4" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Paciente</label>
                <select className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500">
                  <option>Ana Lima</option><option>Pedro Santos</option><option>Mariana Costa</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Data</label>
                  <input type="date" className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Valor (R$)</label>
                  <input type="number" placeholder="0,00" className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Tipo</label>
                <select className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500">
                  <option>Sessão</option><option>Avaliação</option><option>Material</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Forma de pagamento</label>
                <select className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500">
                  <option>PIX</option><option>Cartão de crédito</option><option>Cartão de débito</option><option>Dinheiro</option><option>Transferência</option>
                </select>
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" fullWidth onClick={() => setShowModal(false)}>Cancelar</Button>
                <Button fullWidth>Salvar</Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
