import { useState } from 'react'
import { Plus, Search, X } from 'lucide-react'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'
import { Badge } from '../../components/ui/Badge'
import { Input } from '../../components/ui/Input'

const mockPatients = [
  { id: '1', name: 'Ana Lima', age: 7, diagnosis: 'Atraso no desenvolvimento', status: 'ativo' as const, initials: 'AL' },
  { id: '2', name: 'Pedro Santos', age: 12, diagnosis: 'TDAH', status: 'ativo' as const, initials: 'PS' },
  { id: '3', name: 'Mariana Costa', age: 5, diagnosis: 'Autismo (TEA)', status: 'ativo' as const, initials: 'MC' },
  { id: '4', name: 'João Oliveira', age: 9, diagnosis: 'Paralisia cerebral', status: 'em_espera' as const, initials: 'JO' },
  { id: '5', name: 'Clara Ferreira', age: 6, diagnosis: 'Síndrome de Down', status: 'ativo' as const, initials: 'CF' },
  { id: '6', name: 'Lucas Mendes', age: 14, diagnosis: 'Dislexia', status: 'inativo' as const, initials: 'LM' },
  { id: '7', name: 'Sofia Rodrigues', age: 4, diagnosis: 'Atraso motor', status: 'ativo' as const, initials: 'SR' },
  { id: '8', name: 'Miguel Alves', age: 8, diagnosis: 'TDAH + Ansiedade', status: 'ativo' as const, initials: 'MA' },
]

const statusVariant = { ativo: 'success' as const, em_espera: 'warning' as const, inativo: 'neutral' as const }
const statusLabel = { ativo: 'Ativo', em_espera: 'Em espera', inativo: 'Inativo' }

export function Pacientes() {
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)

  const filtered = mockPatients.filter(p => p.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-serif text-xl font-semibold text-ink">Meus Pacientes</h2>
        <Button onClick={() => setShowModal(true)}>
          <Plus className="w-4 h-4" /> Novo paciente
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-5" />
        <input
          className="w-full h-12 pl-9 pr-4 rounded-xl border border-gray-200 bg-white text-sm outline-none focus:border-green-500"
          placeholder="Buscar paciente..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(p => (
          <Card key={p.id} className="p-5">
            <div className="flex items-start gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-700 font-bold text-sm flex-shrink-0">
                {p.initials}
              </div>
              <div className="flex-1">
                <p className="font-medium text-ink">{p.name}</p>
                <p className="text-xs text-ink-4">{p.age} anos</p>
              </div>
              <Badge variant={statusVariant[p.status]}>{statusLabel[p.status]}</Badge>
            </div>
            <p className="text-sm text-ink-3 mb-3">{p.diagnosis}</p>
            <button className="text-sm text-green-600 hover:underline font-medium">Ver prontuário →</button>
          </Card>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-serif text-lg font-semibold">Novo paciente</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5 text-ink-4" /></button>
            </div>
            <div className="space-y-3">
              <Input label="Nome completo" placeholder="Nome do paciente" />
              <div className="grid grid-cols-2 gap-3">
                <Input label="Data de nascimento" type="date" />
                <Input label="CPF" placeholder="000.000.000-00" />
              </div>
              <Input label="CID-10 / Diagnóstico" placeholder="ex: F84.0 - Autismo" />
              <Input label="Nome do responsável" placeholder="Nome do responsável" />
              <div className="grid grid-cols-2 gap-3">
                <Input label="Telefone" placeholder="(11) 99999-9999" />
                <Input label="E-mail" type="email" placeholder="email@exemplo.com" />
              </div>
              <Input label="Convênio / Particular" placeholder="ex: Unimed, Particular" />
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Observações</label>
                <textarea className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500 resize-none h-20" />
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" fullWidth onClick={() => setShowModal(false)}>Cancelar</Button>
                <Button fullWidth>Salvar paciente</Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
