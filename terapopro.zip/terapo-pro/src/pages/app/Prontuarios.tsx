import { useState } from 'react'
import { Search, Plus, X } from 'lucide-react'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'

const patients = [
  { id: '1', name: 'Ana Lima', age: 7, diagnosis: 'Atraso no desenvolvimento' },
  { id: '2', name: 'Pedro Santos', age: 12, diagnosis: 'TDAH' },
  { id: '3', name: 'Mariana Costa', age: 5, diagnosis: 'Autismo (TEA)' },
  { id: '4', name: 'João Oliveira', age: 9, diagnosis: 'Paralisia cerebral' },
  { id: '5', name: 'Clara Ferreira', age: 6, diagnosis: 'Síndrome de Down' },
]

const mockNotes = [
  { date: '02/06/2026', type: 'Sessão presencial', content: 'Paciente demonstrou boa resposta às atividades de coordenação motora fina. Realizado treino de preensão com materiais de diferentes texturas.' },
  { date: '26/05/2026', type: 'Sessão online', content: 'Sessão focada em atividades de regulação sensorial. Orientações passadas para os responsáveis sobre rotina em casa.' },
  { date: '19/05/2026', type: 'Avaliação', content: 'Avaliação de habilidades de vida diária. Paciente demonstra dificuldades em atividades de autocuidado, sendo este o foco para próximo período.' },
]

export function Prontuarios() {
  const [selected, setSelected] = useState(patients[0])
  const [search, setSearch] = useState('')
  const [activeTab, setActiveTab] = useState('evolucao')
  const [showModal, setShowModal] = useState(false)

  const filtered = patients.filter(p => p.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="p-6 h-full">
      <div className="flex gap-4 h-[calc(100vh-8rem)]">
        <Card className="w-72 flex flex-col flex-shrink-0 overflow-hidden">
          <div className="p-4 border-b">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-5" />
              <input
                className="w-full h-10 pl-9 pr-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                placeholder="Buscar..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {filtered.map(p => (
              <button
                key={p.id}
                onClick={() => setSelected(p)}
                className={`w-full text-left px-4 py-3 border-b border-gray-50 transition-colors ${selected.id === p.id ? 'bg-green-10' : 'hover:bg-gray-50'}`}
              >
                <p className={`text-sm font-medium ${selected.id === p.id ? 'text-green-700' : 'text-ink'}`}>{p.name}</p>
                <p className="text-xs text-ink-5 truncate">{p.diagnosis}</p>
              </button>
            ))}
          </div>
        </Card>

        <Card className="flex-1 flex flex-col overflow-hidden">
          <div className="p-5 border-b">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-serif text-xl font-semibold text-ink">{selected.name}</h2>
                <p className="text-sm text-ink-4">{selected.age} anos · {selected.diagnosis}</p>
              </div>
              <Button onClick={() => setShowModal(true)}>
                <Plus className="w-4 h-4" /> Nova evolução
              </Button>
            </div>
            <div className="flex gap-1 mt-4">
              {[['evolucao', 'Evolução'], ['avaliacoes', 'Avaliações'], ['documentos', 'Documentos'], ['historico', 'Histórico']].map(([k, l]) => (
                <button
                  key={k}
                  onClick={() => setActiveTab(k)}
                  className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${activeTab === k ? 'bg-green-500 text-white' : 'text-ink-4 hover:bg-green-10'}`}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-5">
            {activeTab === 'evolucao' && (
              <div className="space-y-4">
                {mockNotes.map((note, i) => (
                  <div key={i} className="border-l-2 border-green-200 pl-4">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-green-600">{note.type}</span>
                      <span className="text-xs text-ink-5">{note.date}</span>
                    </div>
                    <p className="text-sm text-ink-3 leading-relaxed">{note.content}</p>
                  </div>
                ))}
              </div>
            )}
            {activeTab !== 'evolucao' && (
              <div className="flex items-center justify-center h-40 text-ink-5 text-sm">
                Nenhum conteúdo ainda nesta aba.
              </div>
            )}
          </div>
        </Card>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-serif text-lg font-semibold">Nova evolução</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5 text-ink-4" /></button>
            </div>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Data</label>
                  <input type="date" className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Tipo de sessão</label>
                  <select className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500">
                    <option>Presencial</option><option>Online</option><option>Domiciliar</option><option>Escola</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Evolução</label>
                <textarea className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500 resize-none h-32" placeholder="Descreva a evolução do paciente nesta sessão..." />
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" fullWidth onClick={() => setShowModal(false)}>Cancelar</Button>
                <Button fullWidth>Salvar evolução</Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
