import { Users, Calendar, TrendingUp, FileEdit } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts'
import { Card } from '../../components/ui/Card'
import { Badge } from '../../components/ui/Badge'

const weeklyData = [
  { semana: 'S1', sessoes: 12 }, { semana: 'S2', sessoes: 15 },
  { semana: 'S3', sessoes: 11 }, { semana: 'S4', sessoes: 18 },
  { semana: 'S5', sessoes: 14 }, { semana: 'S6', sessoes: 20 },
  { semana: 'S7', sessoes: 16 }, { semana: 'S8', sessoes: 18 },
]

const pieData = [
  { name: 'Presencial', value: 45 },
  { name: 'Online', value: 30 },
  { name: 'Domiciliar', value: 15 },
  { name: 'Escola', value: 10 },
]

const PIE_COLORS = ['#2d7a3a', '#3d9b4d', '#82c98b', '#b4e0ba']

const todayAppointments = [
  { time: '08:00', patient: 'Ana Lima', type: 'Presencial', status: 'confirmado' as const },
  { time: '09:00', patient: 'Pedro Santos', type: 'Online', status: 'confirmado' as const },
  { time: '10:30', patient: 'Mariana Costa', type: 'Domiciliar', status: 'pendente' as const },
  { time: '14:00', patient: 'João Oliveira', type: 'Escola', status: 'confirmado' as const },
  { time: '15:30', patient: 'Clara Ferreira', type: 'Presencial', status: 'cancelado' as const },
]

const statusVariant = {
  confirmado: 'success' as const,
  pendente: 'warning' as const,
  cancelado: 'danger' as const,
}

const statusLabel = {
  confirmado: 'Confirmado',
  pendente: 'Pendente',
  cancelado: 'Cancelado',
}

const metrics = [
  { label: 'Pacientes ativos', value: '47', icon: Users, color: 'text-green-500' },
  { label: 'Sessões esta semana', value: '18', icon: Calendar, color: 'text-blue-500' },
  { label: 'Receita do mês', value: 'R$ 4.320,00', icon: TrendingUp, color: 'text-green-400' },
  { label: 'Notas pendentes', value: '5', icon: FileEdit, color: 'text-orange-400' },
]

export function Dashboard() {
  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {metrics.map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-ink-4">{label}</span>
              <Icon className={`w-5 h-5 ${color}`} />
            </div>
            <p className="font-serif text-2xl font-semibold text-ink">{value}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-5 gap-4">
        <Card className="xl:col-span-3 p-5">
          <h3 className="font-medium text-ink mb-4">Sessões por semana</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="semana" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Line type="monotone" dataKey="sessoes" stroke="#2d7a3a" strokeWidth={2} dot={{ fill: '#2d7a3a' }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="xl:col-span-2 p-5">
          <h3 className="font-medium text-ink mb-4">Tipo de atendimento</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value">
                {pieData.map((_, i) => (
                  <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Legend iconSize={10} />
              <Tooltip formatter={(v) => `${v}%`} />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card className="p-5">
        <h3 className="font-medium text-ink mb-4">Agenda de hoje</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-ink-4 border-b border-gray-100">
                <th className="pb-3 font-medium">Horário</th>
                <th className="pb-3 font-medium">Paciente</th>
                <th className="pb-3 font-medium">Tipo</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {todayAppointments.map((a, i) => (
                <tr key={i}>
                  <td className="py-3 font-mono text-ink-3">{a.time}</td>
                  <td className="py-3 text-ink font-medium">{a.patient}</td>
                  <td className="py-3 text-ink-4">{a.type}</td>
                  <td className="py-3">
                    <Badge variant={statusVariant[a.status]}>{statusLabel[a.status]}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
