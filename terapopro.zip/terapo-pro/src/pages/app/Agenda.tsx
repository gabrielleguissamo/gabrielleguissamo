import { useState } from 'react'
import { Plus, ChevronLeft, ChevronRight, X } from 'lucide-react'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'

const DAYS = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom']
const HOURS = Array.from({ length: 14 }, (_, i) => `${String(i + 7).padStart(2, '0')}:00`)

const mockSessions = [
  { day: 0, hour: '08:00', patient: 'Ana Lima', type: 'Presencial', status: 'confirmado' as const },
  { day: 0, hour: '10:00', patient: 'Pedro Santos', type: 'Online', status: 'pendente' as const },
  { day: 1, hour: '09:00', patient: 'Mariana Costa', type: 'Domiciliar', status: 'confirmado' as const },
  { day: 2, hour: '14:00', patient: 'João Oliveira', type: 'Escola', status: 'confirmado' as const },
  { day: 3, hour: '11:00', patient: 'Clara Ferreira', type: 'Presencial', status: 'cancelado' as const },
  { day: 4, hour: '15:00', patient: 'Lucas Mendes', type: 'Online', status: 'confirmado' as const },
]

const statusColors = {
  confirmado: 'bg-green-100 text-green-700 border-l-2 border-green-500',
  pendente: 'bg-yellow-50 text-yellow-700 border-l-2 border-yellow-400',
  cancelado: 'bg-gray-100 text-gray-500 border-l-2 border-gray-300 line-through',
}

const PATIENTS = ['Ana Lima', 'Pedro Santos', 'Mariana Costa', 'João Oliveira', 'Clara Ferreira', 'Lucas Mendes']

export function Agenda() {
  const [showModal, setShowModal] = useState(false)
  const [view, setView] = useState<'semana' | 'dia' | 'mes'>('semana')

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl p-1">
          {(['dia', 'semana', 'mes'] as const).map(v => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${view === v ? 'bg-green-500 text-white' : 'text-ink-4 hover:text-ink'}`}
            >
              {v.charAt(0).toUpperCase() + v.slice(1)}
            </button>
          ))}
        </div>
        <Button onClick={() => setShowModal(true)}>
          <Plus className="w-4 h-4" /> Nova sessão
        </Button>
      </div>

      <Card className="overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b">
          <button className="p-1 text-ink-4 hover:text-ink"><ChevronLeft className="w-5 h-5" /></button>
          <span className="font-medium text-ink">Semana de 2 a 8 de junho</span>
          <button className="p-1 text-ink-4 hover:text-ink"><ChevronRight className="w-5 h-5" /></button>
        </div>
        <div className="overflow-auto">
          <div className="grid" style={{ gridTemplateColumns: '60px repeat(7, 1fr)', minWidth: '700px' }}>
            <div className="border-b border-r h-10" />
            {DAYS.map(d => (
              <div key={d} className="border-b border-r h-10 flex items-center justify-center text-sm font-medium text-ink-3">
                {d}
              </div>
            ))}
            {HOURS.map(hour => (
              <>
                <div key={hour} className="border-b border-r px-2 py-1 text-xs text-ink-5">{hour}</div>
                {DAYS.map((_, dayIdx) => {
                  const session = mockSessions.find(s => s.day === dayIdx && s.hour === hour)
                  return (
                    <div key={dayIdx} className="border-b border-r h-12 p-1 relative">
                      {session && (
                        <div className={`text-xs rounded px-1 py-0.5 truncate ${statusColors[session.status]}`}>
                          {session.patient}
                        </div>
                      )}
                    </div>
                  )
                })}
              </>
            ))}
          </div>
        </div>
      </Card>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-serif text-lg font-semibold">Nova sessão</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5 text-ink-4" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Paciente</label>
                <select className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500">
                  {PATIENTS.map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Data</label>
                  <input type="date" className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Horário</label>
                  <input type="time" className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Duração</label>
                <select className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500">
                  <option>30 min</option><option>45 min</option><option>60 min</option><option>90 min</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Tipo</label>
                <select className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500">
                  <option>Presencial</option><option>Online</option><option>Domiciliar</option><option>Escola</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Observações</label>
                <textarea className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500 resize-none h-20" />
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" fullWidth onClick={() => setShowModal(false)}>Cancelar</Button>
                <Button fullWidth>Salvar</Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
