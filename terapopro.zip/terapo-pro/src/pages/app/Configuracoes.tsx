import { useState } from 'react'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { Badge } from '../../components/ui/Badge'
import { useAuth } from '../../contexts/AuthContext'

export function Configuracoes() {
  const { profile } = useAuth()
  const [activeTab, setActiveTab] = useState('perfil')

  const tabs = [
    ['perfil', 'Perfil'],
    ['notificacoes', 'Notificações'],
    ['plano', 'Plano'],
    ['seguranca', 'Segurança'],
  ]

  return (
    <div className="p-6 space-y-4">
      <div className="flex gap-1 bg-white border border-gray-100 rounded-xl p-1 w-fit">
        {tabs.map(([k, l]) => (
          <button
            key={k}
            onClick={() => setActiveTab(k)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${activeTab === k ? 'bg-green-500 text-white' : 'text-ink-4 hover:bg-green-10'}`}
          >
            {l}
          </button>
        ))}
      </div>

      {activeTab === 'perfil' && (
        <Card className="p-6 max-w-xl">
          <h3 className="font-serif text-lg font-semibold text-ink mb-4">Dados do perfil</h3>
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center text-white text-xl font-bold">
              {profile?.full_name?.charAt(0) ?? 'T'}
            </div>
            <Button variant="outline" className="text-sm h-9">Alterar foto</Button>
          </div>
          <div className="space-y-3">
            <Input label="Nome completo" defaultValue={profile?.full_name ?? ''} />
            <Input label="CRF/TO" defaultValue={profile?.crf_to ?? ''} placeholder="TO-SP 12345" />
            <div>
              <label className="text-sm font-medium text-ink-2 block mb-1">Bio</label>
              <textarea className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500 resize-none h-24" placeholder="Descreva suas especialidades e experiência..." />
            </div>
            <Button>Salvar alterações</Button>
          </div>
        </Card>
      )}

      {activeTab === 'notificacoes' && (
        <Card className="p-6 max-w-xl">
          <h3 className="font-serif text-lg font-semibold text-ink mb-4">Notificações</h3>
          <div className="space-y-4">
            {[
              ['Lembretes de sessão por e-mail', true],
              ['Confirmação de consulta', true],
              ['Relatório semanal', false],
              ['Atualizações do sistema', true],
            ].map(([label, defaultVal]) => (
              <div key={label as string} className="flex items-center justify-between py-2 border-b border-gray-50">
                <span className="text-sm text-ink">{label as string}</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" defaultChecked={defaultVal as boolean} className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-green-500 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all" />
                </label>
              </div>
            ))}
          </div>
        </Card>
      )}

      {activeTab === 'plano' && (
        <Card className="p-6 max-w-xl">
          <h3 className="font-serif text-lg font-semibold text-ink mb-4">Seu plano</h3>
          <div className="flex items-center gap-3 mb-6 p-4 bg-green-10 rounded-xl">
            <div>
              <p className="font-medium text-ink">Plano Inicial</p>
              <p className="text-sm text-ink-4">Até 10 pacientes ativos</p>
            </div>
            <Badge variant="success">Ativo</Badge>
          </div>
          <Button>Fazer upgrade</Button>
        </Card>
      )}

      {activeTab === 'seguranca' && (
        <Card className="p-6 max-w-xl">
          <h3 className="font-serif text-lg font-semibold text-ink mb-4">Segurança</h3>
          <div className="space-y-3">
            <Input label="Senha atual" type="password" placeholder="••••••••" />
            <Input label="Nova senha" type="password" placeholder="Mínimo 8 caracteres" />
            <Input label="Confirmar nova senha" type="password" placeholder="Repita a nova senha" />
            <Button>Alterar senha</Button>
          </div>
        </Card>
      )}
    </div>
  )
}
