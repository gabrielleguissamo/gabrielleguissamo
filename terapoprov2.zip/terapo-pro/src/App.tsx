import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext'
import { ProtectedRoute } from './components/auth/ProtectedRoute'
import { AppLayout } from './components/layout/AppLayout'

import { Login } from './pages/auth/Login'
import { Cadastro } from './pages/auth/Cadastro'
import { RecuperarSenha } from './pages/auth/RecuperarSenha'
import { Callback } from './pages/auth/Callback'
import { ResetSenha } from './pages/auth/ResetSenha'

import { Dashboard } from './pages/app/Dashboard'
import { Agenda } from './pages/app/Agenda'
import { Pacientes } from './pages/app/Pacientes'
import { Prontuarios } from './pages/app/Prontuarios'
import { Financeiro } from './pages/app/Financeiro'
import { Relatorios } from './pages/app/Relatorios'
import { Configuracoes } from './pages/app/Configuracoes'

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/cadastro" element={<Cadastro />} />
          <Route path="/recuperar-senha" element={<RecuperarSenha />} />
          <Route path="/auth/callback" element={<Callback />} />
          <Route path="/auth/reset" element={<ResetSenha />} />

          <Route
            element={
              <ProtectedRoute>
                <AppLayout />
              </ProtectedRoute>
            }
          >
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/agenda" element={<Agenda />} />
            <Route path="/pacientes" element={<Pacientes />} />
            <Route path="/prontuarios" element={<Prontuarios />} />
            <Route path="/financeiro" element={<Financeiro />} />
            <Route path="/relatorios" element={<Relatorios />} />
            <Route path="/configuracoes" element={<Configuracoes />} />
          </Route>

          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  )
}
