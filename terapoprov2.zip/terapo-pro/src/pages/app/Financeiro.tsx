import { useState, useEffect } from 'react'
import { Plus, X, TrendingUp, Calendar, DollarSign, AlertCircle } from 'lucide-react'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'
import { Badge } from '../../components/ui/Badge'
import { Toast } from '../../components/ui/Toast'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import type { Transaction, Patient } from '../../types'

const statusVariant = { pago: 'success' as const, pendente: 'warning' as const, cancelado: 'danger' as const }
const statusLabel = { pago: 'Pago', pendente: 'Pendente', cancelado: 'Cancelado' }

type TransactionWithPatient = Transaction & { patients?: { name: string } }

function formatBRL(value: number) {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
}

function getMonthOptions() {
  const months = []
  const now = new Date()
  for (let i = 0; i < 12; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
    const label = d.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })
    months.push({ key, label: label.charAt(0).toUpperCase() + label.slice(1) })
  }
  return months
}

export function Financeiro() {
  const { user } = useAuth()
  const [transactions, setTransactions] = useState<TransactionWithPatient[]>([])
  const [patients, setPatients] = useState<Patient[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)

  const monthOptions = getMonthOptions()
  const [selectedMonth, setSelectedMonth] = useState(monthOptions[0].key)
  const [statusFilter, setStatusFilter] = useState('')

  const [form, setForm] = useState({
    patient_id: '', date: '', amount: '', type: 'sessao' as Transaction['type'],
    payment_method: 'PIX', status: 'pendente' as Transaction['status'],
  })

  async function fetchTransactions() {
    if (!user) return
    setLoading(true)
    const { data, error } = await supabase
      .from('transactions')
      .select('*, patients(name)')
      .eq('user_id', user.id)
      .order('date', { ascending: false })
    if (error) {
      setToast({ message: 'Erro ao carregar lançamentos', type: 'error' })
    } else {
      setTransactions((data ?? []) as TransactionWithPatient[])
    }
    setLoading(false)
  }

  async function fetchPatients() {
    if (!user) return
    const { data } = await supabase
      .from('patients')
      .select('id, name, status')
      .eq('user_id', user.id)
      .order('name', { ascending: true })
    if (data) setPatients(data as Patient[])
  }

  useEffect(() => { fetchTransactions(); fetchPatients() }, [user])

  async function handleSave() {
    if (!user || !form.date || !form.amount) return
    setSaving(true)
    const { error } = await supabase.from('transactions').insert({
      user_id: user.id,
      patient_id: form.patient_id || null,
      date: form.date,
      amount: parseFloat(form.amount),
      type: form.type,
      payment_method: form.payment_method,
      status: form.status,
    })
    setSaving(false)
    if (error) {
      setToast({ message: 'Erro ao salvar lançamento', type: 'error' })
    } else {
      setToast({ message: 'Lançamento salvo!', type: 'success' })
      setShowModal(false)
      setForm({ patient_id: '', date: '', amount: '', type: 'sessao', payment_method: 'PIX', status: 'pendente' })
      fetchTransactions()
    }
  }

  const filtered = transactions.filter(t => {
    const monthMatch = t.date.startsWith(selectedMonth)
    const statusMatch = !statusFilter || t.status === statusFilter
    return monthMatch && statusMatch
  })

  // Metrics from current month transactions
  const currentMonth = transactions.filter(t => t.date.startsWith(selectedMonth))
  const monthRevenue = currentMonth.filter(t => t.status === 'pago').reduce((sum, t) => sum + t.amount, 0)
  const sessionCount = currentMonth.filter(t => t.type === 'sessao').length
  const paidSessions = currentMonth.filter(t => t.type === 'sessao' && t.status === 'pago')
  const avgTicket = paidSessions.length > 0 ? paidSessions.reduce((s, t) => s + t.amount, 0) / paidSessions.length : 0
  const overdue = currentMonth.filter(t => t.status === 'pendente').reduce((sum, t) => sum + t.amount, 0)

  const metrics = [
    { label: 'Receita do mês', value: formatBRL(monthRevenue), icon: TrendingUp, color: 'text-green-500' },
    { label: 'Sessões realizadas', value: String(sessionCount), icon: Calendar, color: 'text-blue-500' },
    { label: 'Ticket médio', value: formatBRL(avgTicket), icon: DollarSign, color: 'text-green-400' },
    { label: 'Inadimplência', value: formatBRL(overdue), icon: AlertCircle, color: 'text-orange-400' },
  ]

  return (
    <div className="p-6 space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {metrics.map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-ink-4">{label}</span>
              <Icon className={`w-5 h-5 ${color}`} />
            </div>
            <p className="font-serif text-2xl font-semibold text-ink">{value}</p>
          </Card>
        ))}
      </div>

      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex gap-3">
            <select
              className="h-10 px-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
              value={selectedMonth}
              onChange={e => setSelectedMonth(e.target.value)}
            >
              {monthOptions.map(m => <option key={m.key} value={m.key}>{m.label}</option>)}
            </select>
            <select
              className="h-10 px-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
            >
              <option value="">Todos os status</option>
              <option value="pago">Pago</option>
              <option value="pendente">Pendente</option>
              <option value="cancelado">Cancelado</option>
            </select>
          </div>
          <Button onClick={() => setShowModal(true)}>
            <Plus className="w-4 h-4" /> Novo lançamento
          </Button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-40">
            <div className="w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-ink-4 border-b border-gray-100">
                  <th className="pb-3 font-medium">Data</th>
                  <th className="pb-3 font-medium">Paciente</th>
                  <th className="pb-3 font-medium">Tipo</th>
                  <th className="pb-3 font-medium">Valor</th>
                  <th className="pb-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-ink-5">Nenhum lançamento encontrado.</td>
                  </tr>
                ) : filtered.map(t => (
                  <tr key={t.id}>
                    <td className="py-3 text-ink-4">{new Date(t.date + 'T12:00:00').toLocaleDateString('pt-BR')}</td>
                    <td className="py-3 text-ink font-medium">{t.patients?.name ?? '—'}</td>
                    <td className="py-3 text-ink-3 capitalize">{t.type}</td>
                    <td className="py-3 font-medium text-ink">{formatBRL(t.amount)}</td>
                    <td className="py-3"><Badge variant={statusVariant[t.status]}>{statusLabel[t.status]}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-serif text-lg font-semibold">Novo lançamento</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5 text-ink-4" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Paciente</label>
                <select
                  className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                  value={form.patient_id}
                  onChange={e => setForm(f => ({ ...f, patient_id: e.target.value }))}
                >
                  <option value="">Sem paciente</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Data</label>
                  <input
                    type="date"
                    className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                    value={form.date}
                    onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Valor (R$)</label>
                  <input
                    type="number"
                    placeholder="0,00"
                    className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                    value={form.amount}
                    onChange={e => setForm(f => ({ ...f, amount: e.target.value }))}
                  />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Tipo</label>
                <select
                  className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                  value={form.type}
                  onChange={e => setForm(f => ({ ...f, type: e.target.value as Transaction['type'] }))}
                >
                  <option value="sessao">Sessão</option>
                  <option value="avaliacao">Avaliação</option>
                  <option value="material">Material</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Forma de pagamento</label>
                <select
                  className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                  value={form.payment_method}
                  onChange={e => setForm(f => ({ ...f, payment_method: e.target.value }))}
                >
                  <option>PIX</option>
                  <option>Cartão de crédito</option>
                  <option>Cartão de débito</option>
                  <option>Dinheiro</option>
                  <option>Transferência</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Status</label>
                <select
                  className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                  value={form.status}
                  onChange={e => setForm(f => ({ ...f, status: e.target.value as Transaction['status'] }))}
                >
                  <option value="pendente">Pendente</option>
                  <option value="pago">Pago</option>
                  <option value="cancelado">Cancelado</option>
                </select>
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" fullWidth onClick={() => setShowModal(false)}>Cancelar</Button>
                <Button fullWidth onClick={handleSave} disabled={saving || !form.date || !form.amount}>
                  {saving ? 'Salvando...' : 'Salvar'}
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  )
}
