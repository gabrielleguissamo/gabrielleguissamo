import { useState } from 'react'
import { TrendingUp, Calendar, DollarSign, Download } from 'lucide-react'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'

const reports = [
  { icon: TrendingUp, title: 'Evolução por paciente', desc: 'Acompanhe o progresso individual de cada paciente ao longo do tempo.' },
  { icon: Calendar, title: 'Frequência de sessões', desc: 'Visualize a assiduidade e padrões de comparecimento dos pacientes.' },
  { icon: DollarSign, title: 'Relatório financeiro', desc: 'Análise detalhada de receitas, despesas e inadimplência.' },
  { icon: Download, title: 'Exportar dados (CSV)', desc: 'Exporte todos os seus dados para análise em planilhas.' },
]

export function Relatorios() {
  const [loading, setLoading] = useState<number | null>(null)

  const handleGenerate = (i: number) => {
    setLoading(i)
    setTimeout(() => setLoading(null), 2000)
  }

  return (
    <div className="p-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reports.map(({ icon: Icon, title, desc }, i) => (
          <Card key={i} className="p-6">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-10 h-10 rounded-xl bg-green-10 flex items-center justify-center flex-shrink-0">
                <Icon className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h3 className="font-medium text-ink">{title}</h3>
                <p className="text-sm text-ink-4 mt-0.5">{desc}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <select className="flex-1 h-10 px-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500">
                <option>Últimos 30 dias</option><option>Últimos 90 dias</option><option>Este ano</option>
              </select>
              <Button onClick={() => handleGenerate(i)} loading={loading === i} variant="outline">
                {loading === i ? '' : 'Gerar'}
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
