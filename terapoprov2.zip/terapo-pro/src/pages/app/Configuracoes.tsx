import { useState, useEffect, useRef } from 'react'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { Badge } from '../../components/ui/Badge'
import { Toast } from '../../components/ui/Toast'
import { useAuth } from '../../contexts/AuthContext'
import { supabase } from '../../lib/supabase'

export function Configuracoes() {
  const { user, profile, refreshProfile } = useAuth()
  const [activeTab, setActiveTab] = useState('perfil')
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)

  // Profile form
  const [fullName, setFullName] = useState('')
  const [crfTo, setCrfTo] = useState('')
  const [bio, setBio] = useState('')
  const [avatarUrl, setAvatarUrl] = useState('')
  const [savingProfile, setSavingProfile] = useState(false)
  const [uploadingPhoto, setUploadingPhoto] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name ?? '')
      setCrfTo(profile.crf_to ?? '')
      setAvatarUrl(profile.avatar_url ?? '')
    }
  }, [profile])

  async function handlePhotoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file || !user) return
    setUploadingPhoto(true)
    const ext = file.name.split('.').pop()
    const path = `avatars/${user.id}.${ext}`
    const { error: uploadError } = await supabase.storage.from('avatars').upload(path, file, { upsert: true })
    if (uploadError) {
      setToast({ message: 'Erro ao enviar foto', type: 'error' })
    } else {
      const { data } = supabase.storage.from('avatars').getPublicUrl(path)
      const url = data.publicUrl
      await supabase.from('profiles').update({ avatar_url: url }).eq('id', user.id)
      setAvatarUrl(url)
      await refreshProfile()
      setToast({ message: 'Foto atualizada!', type: 'success' })
    }
    setUploadingPhoto(false)
  }

  // Security form
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [savingPassword, setSavingPassword] = useState(false)

  async function handleSaveProfile() {
    if (!user) return
    setSavingProfile(true)
    const { error } = await supabase
      .from('profiles')
      .update({ full_name: fullName, crf_to: crfTo })
      .eq('id', user.id)
    setSavingProfile(false)
    if (error) {
      setToast({ message: 'Erro ao salvar perfil', type: 'error' })
    } else {
      await refreshProfile()
      setToast({ message: 'Perfil atualizado!', type: 'success' })
    }
  }

  async function handleChangePassword() {
    if (!newPassword || newPassword !== confirmPassword) {
      setToast({ message: 'As senhas não coincidem', type: 'error' })
      return
    }
    if (newPassword.length < 8) {
      setToast({ message: 'A senha deve ter pelo menos 8 caracteres', type: 'error' })
      return
    }
    setSavingPassword(true)
    const { error } = await supabase.auth.updateUser({ password: newPassword })
    setSavingPassword(false)
    if (error) {
      setToast({ message: error.message ?? 'Erro ao alterar senha', type: 'error' })
    } else {
      setToast({ message: 'Senha alterada com sucesso!', type: 'success' })
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
    }
  }

  const tabs = [
    ['perfil', 'Perfil'],
    ['notificacoes', 'Notificações'],
    ['plano', 'Plano'],
    ['seguranca', 'Segurança'],
  ]

  return (
    <div className="p-6 space-y-4">
      <div className="flex gap-1 bg-white border border-gray-100 rounded-xl p-1 w-fit">
        {tabs.map(([k, l]) => (
          <button
            key={k}
            onClick={() => setActiveTab(k)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${activeTab === k ? 'bg-green-500 text-white' : 'text-ink-4 hover:bg-green-10'}`}
          >
            {l}
          </button>
        ))}
      </div>

      {activeTab === 'perfil' && (
        <Card className="p-6 max-w-xl">
          <h3 className="font-serif text-lg font-semibold text-ink mb-4">Dados do perfil</h3>
          <div className="flex items-center gap-4 mb-6">
            {avatarUrl ? (
              <img src={avatarUrl} alt="Avatar" className="w-16 h-16 rounded-full object-cover" />
            ) : (
              <div className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center text-white text-xl font-bold">
                {fullName?.charAt(0)?.toUpperCase() ?? 'T'}
              </div>
            )}
            <div>
              <Button variant="outline" className="text-sm h-9" onClick={() => fileInputRef.current?.click()} loading={uploadingPhoto}>
                {uploadingPhoto ? '' : 'Alterar foto'}
              </Button>
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
              <p className="text-xs text-ink-5 mt-1">JPG, PNG ou GIF. Máx 2MB.</p>
            </div>
          </div>
          <div className="space-y-3">
            <Input
              label="Nome completo"
              value={fullName}
              onChange={e => setFullName(e.target.value)}
            />
            <Input
              label="CRF/TO"
              value={crfTo}
              onChange={e => setCrfTo(e.target.value)}
              placeholder="TO-SP 12345"
            />
            <div>
              <label className="text-sm font-medium text-ink-2 block mb-1">Bio</label>
              <textarea
                className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500 resize-none h-24"
                placeholder="Descreva suas especialidades e experiência..."
                value={bio}
                onChange={e => setBio(e.target.value)}
              />
            </div>
            <Button onClick={handleSaveProfile} disabled={savingProfile}>
              {savingProfile ? 'Salvando...' : 'Salvar alterações'}
            </Button>
          </div>
        </Card>
      )}

      {activeTab === 'notificacoes' && (
        <Card className="p-6 max-w-xl">
          <h3 className="font-serif text-lg font-semibold text-ink mb-4">Notificações</h3>
          <div className="space-y-4">
            {[
              ['Lembretes de sessão por e-mail', true],
              ['Confirmação de consulta', true],
              ['Relatório semanal', false],
              ['Atualizações do sistema', true],
            ].map(([label, defaultVal]) => (
              <div key={label as string} className="flex items-center justify-between py-2 border-b border-gray-50">
                <span className="text-sm text-ink">{label as string}</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" defaultChecked={defaultVal as boolean} className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-green-500 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all" />
                </label>
              </div>
            ))}
          </div>
        </Card>
      )}

      {activeTab === 'plano' && (
        <Card className="p-6 max-w-xl">
          <h3 className="font-serif text-lg font-semibold text-ink mb-4">Seu plano</h3>
          <div className="flex items-center gap-3 mb-6 p-4 bg-green-10 rounded-xl">
            <div>
              <p className="font-medium text-ink">Plano Inicial</p>
              <p className="text-sm text-ink-4">Até 10 pacientes ativos</p>
            </div>
            <Badge variant="success">Ativo</Badge>
          </div>
          <Button>Fazer upgrade</Button>
        </Card>
      )}

      {activeTab === 'seguranca' && (
        <Card className="p-6 max-w-xl">
          <h3 className="font-serif text-lg font-semibold text-ink mb-4">Segurança</h3>
          <div className="space-y-3">
            <Input
              label="Senha atual"
              type="password"
              placeholder="••••••••"
              value={currentPassword}
              onChange={e => setCurrentPassword(e.target.value)}
            />
            <Input
              label="Nova senha"
              type="password"
              placeholder="Mínimo 8 caracteres"
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
            />
            <Input
              label="Confirmar nova senha"
              type="password"
              placeholder="Repita a nova senha"
              value={confirmPassword}
              onChange={e => setConfirmPassword(e.target.value)}
            />
            <Button onClick={handleChangePassword} disabled={savingPassword}>
              {savingPassword ? 'Alterando...' : 'Alterar senha'}
            </Button>
          </div>
        </Card>
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  )
}
