import { useState, useEffect } from 'react'
import { Plus, Search, X, Trash2 } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'
import { Badge } from '../../components/ui/Badge'
import { Input } from '../../components/ui/Input'
import { Toast } from '../../components/ui/Toast'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import type { Patient } from '../../types'

const statusVariant = { ativo: 'success' as const, em_espera: 'warning' as const, inativo: 'neutral' as const }
const statusLabel = { ativo: 'Ativo', em_espera: 'Em espera', inativo: 'Inativo' }

function calcAge(birth_date: string): number {
  const today = new Date()
  const birth = new Date(birth_date)
  let age = today.getFullYear() - birth.getFullYear()
  const m = today.getMonth() - birth.getMonth()
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--
  return age
}

function initials(name: string): string {
  const parts = name.trim().split(' ')
  if (parts.length === 1) return parts[0].charAt(0).toUpperCase()
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase()
}

export function Pacientes() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [patients, setPatients] = useState<Patient[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)

  // Form state
  const [form, setForm] = useState<{
    name: string; birth_date: string; cpf: string; diagnosis: string;
    guardian_name: string; phone: string; email: string; insurance: string;
    status: Patient['status']; notes: string;
  }>({
    name: '', birth_date: '', cpf: '', diagnosis: '',
    guardian_name: '', phone: '', email: '', insurance: '',
    status: 'ativo', notes: '',
  })

  async function fetchPatients() {
    if (!user) return
    setLoading(true)
    const { data, error } = await supabase
      .from('patients')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
    if (error) {
      setToast({ message: 'Erro ao carregar pacientes', type: 'error' })
    } else {
      setPatients((data ?? []) as Patient[])
    }
    setLoading(false)
  }

  useEffect(() => { fetchPatients() }, [user])

  async function handleSave() {
    if (!user || !form.name) return
    setSaving(true)
    const { error } = await supabase.from('patients').insert({
      user_id: user.id,
      name: form.name,
      birth_date: form.birth_date || null,
      cpf: form.cpf || null,
      diagnosis: form.diagnosis || null,
      guardian_name: form.guardian_name || null,
      phone: form.phone || null,
      email: form.email || null,
      insurance: form.insurance || null,
      status: form.status,
    })
    setSaving(false)
    if (error) {
      setToast({ message: 'Erro ao salvar paciente', type: 'error' })
    } else {
      setToast({ message: 'Paciente salvo com sucesso!', type: 'success' })
      setShowModal(false)
      setForm({ name: '', birth_date: '', cpf: '', diagnosis: '', guardian_name: '', phone: '', email: '', insurance: '', status: 'ativo', notes: '' })
      fetchPatients()
    }
  }

  async function handleDelete(id: string) {
    if (!window.confirm('Deseja excluir este paciente?')) return
    const { error } = await supabase.from('patients').delete().eq('id', id)
    if (error) {
      setToast({ message: 'Erro ao excluir paciente', type: 'error' })
    } else {
      setToast({ message: 'Paciente excluído', type: 'success' })
      setPatients(prev => prev.filter(p => p.id !== id))
    }
  }

  const filtered = patients.filter(p => p.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-serif text-xl font-semibold text-ink">Meus Pacientes</h2>
        <Button onClick={() => setShowModal(true)}>
          <Plus className="w-4 h-4" /> Novo paciente
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-5" />
        <input
          className="w-full h-12 pl-9 pr-4 rounded-xl border border-gray-200 bg-white text-sm outline-none focus:border-green-500"
          placeholder="Buscar paciente..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-40">
          <div className="w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map(p => (
            <Card key={p.id} className="p-5">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-700 font-bold text-sm flex-shrink-0">
                  {initials(p.name)}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-ink">{p.name}</p>
                  <p className="text-xs text-ink-4">{p.birth_date ? `${calcAge(p.birth_date)} anos` : '—'}</p>
                </div>
                <Badge variant={statusVariant[p.status]}>{statusLabel[p.status]}</Badge>
              </div>
              <p className="text-sm text-ink-3 mb-3">{p.diagnosis ?? '—'}</p>
              <div className="flex items-center justify-between">
                <button
                  className="text-sm text-green-600 hover:underline font-medium"
                  onClick={() => navigate(`/prontuarios?patient=${p.id}`)}
                >
                  Ver prontuário →
                </button>
                <button
                  className="text-ink-4 hover:text-red-500 transition-colors"
                  onClick={() => handleDelete(p.id)}
                  title="Excluir paciente"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </Card>
          ))}
          {filtered.length === 0 && (
            <p className="col-span-3 text-center text-ink-4 text-sm py-12">Nenhum paciente encontrado.</p>
          )}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-serif text-lg font-semibold">Novo paciente</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5 text-ink-4" /></button>
            </div>
            <div className="space-y-3">
              <Input label="Nome completo" placeholder="Nome do paciente" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
              <div className="grid grid-cols-2 gap-3">
                <Input label="Data de nascimento" type="date" value={form.birth_date} onChange={e => setForm(f => ({ ...f, birth_date: e.target.value }))} />
                <Input label="CPF" placeholder="000.000.000-00" value={form.cpf} onChange={e => setForm(f => ({ ...f, cpf: e.target.value }))} />
              </div>
              <Input label="CID-10 / Diagnóstico" placeholder="ex: F84.0 - Autismo" value={form.diagnosis} onChange={e => setForm(f => ({ ...f, diagnosis: e.target.value }))} />
              <Input label="Nome do responsável" placeholder="Nome do responsável" value={form.guardian_name} onChange={e => setForm(f => ({ ...f, guardian_name: e.target.value }))} />
              <div className="grid grid-cols-2 gap-3">
                <Input label="Telefone" placeholder="(11) 99999-9999" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
                <Input label="E-mail" type="email" placeholder="email@exemplo.com" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
              </div>
              <Input label="Convênio / Particular" placeholder="ex: Unimed, Particular" value={form.insurance} onChange={e => setForm(f => ({ ...f, insurance: e.target.value }))} />
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Status</label>
                <select
                  className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                  value={form.status}
                  onChange={e => setForm(f => ({ ...f, status: e.target.value as Patient['status'] }))}
                >
                  <option value="ativo">Ativo</option>
                  <option value="em_espera">Em espera</option>
                  <option value="inativo">Inativo</option>
                </select>
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" fullWidth onClick={() => setShowModal(false)}>Cancelar</Button>
                <Button fullWidth onClick={handleSave} disabled={saving || !form.name}>
                  {saving ? 'Salvando...' : 'Salvar paciente'}
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  )
}
