import { useState, useEffect } from 'react'
import { Search, Plus, X } from 'lucide-react'
import { useSearchParams } from 'react-router-dom'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'
import { Toast } from '../../components/ui/Toast'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import type { Patient, MedicalRecord } from '../../types'

export function Prontuarios() {
  const { user } = useAuth()
  const [searchParams] = useSearchParams()
  const [patients, setPatients] = useState<Patient[]>([])
  const [selected, setSelected] = useState<Patient | null>(null)
  const [records, setRecords] = useState<MedicalRecord[]>([])
  const [loadingPatients, setLoadingPatients] = useState(true)
  const [loadingRecords, setLoadingRecords] = useState(false)
  const [search, setSearch] = useState('')
  const [activeTab, setActiveTab] = useState('evolucao')
  const [showModal, setShowModal] = useState(false)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)

  // Form state
  const [form, setForm] = useState({ date: '', session_type: 'Presencial', content: '' })

  async function fetchPatients() {
    if (!user) return
    setLoadingPatients(true)
    const { data, error } = await supabase
      .from('patients')
      .select('*')
      .eq('user_id', user.id)
      .order('name', { ascending: true })
    if (!error && data) {
      const list = data as Patient[]
      setPatients(list)
      // Pre-select from URL param
      const paramId = searchParams.get('patient')
      if (paramId) {
        const found = list.find(p => p.id === paramId)
        if (found) setSelected(found)
        else if (list.length > 0) setSelected(list[0])
      } else if (list.length > 0) {
        setSelected(list[0])
      }
    }
    setLoadingPatients(false)
  }

  async function fetchRecords(patientId: string) {
    setLoadingRecords(true)
    const { data, error } = await supabase
      .from('records')
      .select('*')
      .eq('patient_id', patientId)
      .order('date', { ascending: false })
      .order('created_at', { ascending: false })
    if (error) {
      setToast({ message: 'Erro ao carregar evoluções', type: 'error' })
    } else {
      setRecords((data ?? []) as MedicalRecord[])
    }
    setLoadingRecords(false)
  }

  useEffect(() => { fetchPatients() }, [user])
  useEffect(() => { if (selected) fetchRecords(selected.id) }, [selected])

  async function handleSaveRecord() {
    if (!user || !selected || !form.content) return
    setSaving(true)
    const { error } = await supabase.from('records').insert({
      patient_id: selected.id,
      user_id: user.id,
      date: form.date || new Date().toISOString().slice(0, 10),
      content: form.content,
      assessment_type: form.session_type,
    })
    setSaving(false)
    if (error) {
      setToast({ message: 'Erro ao salvar evolução', type: 'error' })
    } else {
      setToast({ message: 'Evolução salva!', type: 'success' })
      setShowModal(false)
      setForm({ date: '', session_type: 'Presencial', content: '' })
      if (selected) fetchRecords(selected.id)
    }
  }

  function formatDate(dateStr: string) {
    const d = new Date(dateStr)
    return d.toLocaleDateString('pt-BR')
  }

  const filtered = patients.filter(p => p.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="p-6 h-full">
      <div className="flex gap-4 h-[calc(100vh-8rem)]">
        <Card className="w-72 flex flex-col flex-shrink-0 overflow-hidden">
          <div className="p-4 border-b">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-5" />
              <input
                className="w-full h-10 pl-9 pr-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                placeholder="Buscar..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {loadingPatients ? (
              <div className="flex items-center justify-center h-20">
                <div className="w-6 h-6 border-4 border-green-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : filtered.map(p => (
              <button
                key={p.id}
                onClick={() => setSelected(p)}
                className={`w-full text-left px-4 py-3 border-b border-gray-50 transition-colors ${selected?.id === p.id ? 'bg-green-10' : 'hover:bg-gray-50'}`}
              >
                <p className={`text-sm font-medium ${selected?.id === p.id ? 'text-green-700' : 'text-ink'}`}>{p.name}</p>
                <p className="text-xs text-ink-5 truncate">{p.diagnosis ?? '—'}</p>
              </button>
            ))}
            {!loadingPatients && filtered.length === 0 && (
              <p className="text-xs text-ink-5 text-center py-8">Nenhum paciente encontrado.</p>
            )}
          </div>
        </Card>

        <Card className="flex-1 flex flex-col overflow-hidden">
          {selected ? (
            <>
              <div className="p-5 border-b">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="font-serif text-xl font-semibold text-ink">{selected.name}</h2>
                    <p className="text-sm text-ink-4">{selected.diagnosis ?? '—'}</p>
                  </div>
                  <Button onClick={() => setShowModal(true)}>
                    <Plus className="w-4 h-4" /> Nova evolução
                  </Button>
                </div>
                <div className="flex gap-1 mt-4">
                  {[['evolucao', 'Evolução'], ['avaliacoes', 'Avaliações'], ['documentos', 'Documentos'], ['historico', 'Histórico']].map(([k, l]) => (
                    <button
                      key={k}
                      onClick={() => setActiveTab(k)}
                      className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${activeTab === k ? 'bg-green-500 text-white' : 'text-ink-4 hover:bg-green-10'}`}
                    >
                      {l}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-5">
                {activeTab === 'evolucao' && (
                  loadingRecords ? (
                    <div className="flex items-center justify-center h-40">
                      <div className="w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full animate-spin" />
                    </div>
                  ) : records.length === 0 ? (
                    <div className="flex items-center justify-center h-40 text-ink-5 text-sm">
                      Nenhuma evolução registrada ainda.
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {records.map(note => (
                        <div key={note.id} className="border-l-2 border-green-200 pl-4">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-medium text-green-600">{note.assessment_type ?? 'Sessão'}</span>
                            <span className="text-xs text-ink-5">{formatDate(note.date)}</span>
                          </div>
                          <p className="text-sm text-ink-3 leading-relaxed">{note.content}</p>
                        </div>
                      ))}
                    </div>
                  )
                )}
                {activeTab !== 'evolucao' && (
                  <div className="flex items-center justify-center h-40 text-ink-5 text-sm">
                    Nenhum conteúdo ainda nesta aba.
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-ink-5 text-sm">
              Selecione um paciente.
            </div>
          )}
        </Card>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-serif text-lg font-semibold">Nova evolução</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5 text-ink-4" /></button>
            </div>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Data</label>
                  <input
                    type="date"
                    className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                    value={form.date}
                    onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Tipo de sessão</label>
                  <select
                    className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                    value={form.session_type}
                    onChange={e => setForm(f => ({ ...f, session_type: e.target.value }))}
                  >
                    <option>Presencial</option><option>Online</option><option>Domiciliar</option><option>Escola</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Evolução</label>
                <textarea
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500 resize-none h-32"
                  placeholder="Descreva a evolução do paciente nesta sessão..."
                  value={form.content}
                  onChange={e => setForm(f => ({ ...f, content: e.target.value }))}
                />
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" fullWidth onClick={() => setShowModal(false)}>Cancelar</Button>
                <Button fullWidth onClick={handleSaveRecord} disabled={saving || !form.content}>
                  {saving ? 'Salvando...' : 'Salvar evolução'}
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  )
}
