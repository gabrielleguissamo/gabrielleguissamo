export async function gerarRelatorio(
  briefing: string,
  tipoRelatorio: string,
  nomePaciente: string
): Promise<string> {
  const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY
  if (!apiKey) throw new Error('VITE_ANTHROPIC_API_KEY não configurada')

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages: [
        {
          role: 'user',
          content: `Você é um especialista em Terapia Ocupacional e deve gerar um relatório clínico profissional em português brasileiro.

TIPO DE RELATÓRIO: ${tipoRelatorio}
PACIENTE: ${nomePaciente}

INFORMAÇÕES DA SESSÃO/BRIEFING:
${briefing}

Gere um relatório clínico completo e profissional de Terapia Ocupacional com as seguintes seções:

1. IDENTIFICAÇÃO DO PACIENTE
2. OBJETIVO DO RELATÓRIO
3. HISTÓRICO E CONTEXTO CLÍNICO
4. DESCRIÇÃO DAS ATIVIDADES E INTERVENÇÕES
5. EVOLUÇÃO E RESULTADOS OBSERVADOS
6. ANÁLISE CLÍNICA
7. RECOMENDAÇÕES E PRÓXIMAS ETAPAS
8. CONCLUSÃO

Use linguagem técnica da Terapia Ocupacional. O relatório deve ser formal, objetivo e adequado para ser compartilhado com outros profissionais de saúde, familiares ou instituições. Não inclua nenhuma introdução ou explicação antes do relatório — comece diretamente com o conteúdo.`,
        },
      ],
    }),
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({}))
    throw new Error((err as { error?: { message?: string } }).error?.message ?? 'Erro na API Anthropic')
  }

  const data = await response.json() as { content: { text: string }[] }
  return data.content[0].text
}
