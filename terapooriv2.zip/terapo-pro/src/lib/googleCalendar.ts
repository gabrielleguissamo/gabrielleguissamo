// Google Calendar API integration
// Uses Google Identity Services (GIS) for OAuth2
// Scopes needed: https://www.googleapis.com/auth/calendar.events

const CLIENT_ID = '856149008791-sp2vlfni739sibsg1vh9p4rho2nu0qrq.apps.googleusercontent.com'
const SCOPE = 'https://www.googleapis.com/auth/calendar.events'

declare global {
  interface Window {
    google: {
      accounts: {
        oauth2: {
          initTokenClient: (config: {
            client_id: string
            scope: string
            callback: (response: { access_token?: string; error?: string }) => void
          }) => { requestAccessToken: () => void }
        }
      }
    }
  }
}

// Load GIS script dynamically
export function loadGoogleScript(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (window.google?.accounts?.oauth2) {
      resolve()
      return
    }
    const existing = document.querySelector('script[src="https://accounts.google.com/gsi/client"]')
    if (existing) {
      existing.addEventListener('load', () => resolve())
      existing.addEventListener('error', () => reject(new Error('Failed to load GIS script')))
      return
    }
    const script = document.createElement('script')
    script.src = 'https://accounts.google.com/gsi/client'
    script.async = true
    script.defer = true
    script.onload = () => resolve()
    script.onerror = () => reject(new Error('Failed to load GIS script'))
    document.head.appendChild(script)
  })
}

// Store token in memory only (not localStorage for security)
let accessToken: string | null = null

// Request access token using GIS TokenClient
export function requestGoogleCalendarAccess(): Promise<string> {
  return new Promise(async (resolve, reject) => {
    try {
      await loadGoogleScript()
      const tokenClient = window.google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPE,
        callback: (response) => {
          if (response.error || !response.access_token) {
            reject(new Error(response.error ?? 'No access token received'))
            return
          }
          accessToken = response.access_token
          resolve(response.access_token)
        },
      })
      tokenClient.requestAccessToken()
    } catch (err) {
      reject(err)
    }
  })
}

export function getAccessToken(): string | null {
  return accessToken
}

function toDateTimeLocal(date: string, time: string): string {
  // date: YYYY-MM-DD, time: HH:MM
  return `${date}T${time}:00-03:00`
}

function addMinutes(date: string, time: string, minutes: number): string {
  const dt = new Date(`${date}T${time}:00`)
  dt.setMinutes(dt.getMinutes() + minutes)
  const pad = (n: number) => String(n).padStart(2, '0')
  const endDate = `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())}`
  const endTime = `${pad(dt.getHours())}:${pad(dt.getMinutes())}`
  return toDateTimeLocal(endDate, endTime)
}

// Create a calendar event
export async function createGoogleCalendarEvent(params: {
  title: string
  date: string // YYYY-MM-DD
  time: string // HH:MM
  duration: number // minutes
  description?: string
  type: string
}): Promise<string> {
  const token = accessToken
  if (!token) throw new Error('Not authenticated with Google Calendar')

  const startDateTime = toDateTimeLocal(params.date, params.time)
  const endDateTime = addMinutes(params.date, params.time, params.duration)

  const event = {
    summary: `Sessão - ${params.title}`,
    description: `${params.type} - Terapô.pro${params.description ? '\n' + params.description : ''}`,
    start: { dateTime: startDateTime, timeZone: 'America/Sao_Paulo' },
    end: { dateTime: endDateTime, timeZone: 'America/Sao_Paulo' },
  }

  const response = await fetch(
    'https://www.googleapis.com/calendar/v3/calendars/primary/events',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(event),
    }
  )

  if (!response.ok) {
    throw new Error(`Google Calendar API error: ${response.status}`)
  }

  const data = await response.json()
  return data.id as string
}

// Delete a calendar event
export async function deleteGoogleCalendarEvent(eventId: string): Promise<void> {
  const token = accessToken
  if (!token) throw new Error('Not authenticated with Google Calendar')

  const response = await fetch(
    `https://www.googleapis.com/calendar/v3/calendars/primary/events/${eventId}`,
    {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    }
  )

  if (!response.ok && response.status !== 404) {
    throw new Error(`Google Calendar API error: ${response.status}`)
  }
}

// Update a calendar event
export async function updateGoogleCalendarEvent(
  eventId: string,
  params: {
    title?: string
    date?: string
    time?: string
    duration?: number
    description?: string
    type?: string
  }
): Promise<void> {
  const token = accessToken
  if (!token) throw new Error('Not authenticated with Google Calendar')

  const patch: Record<string, unknown> = {}
  if (params.title) patch.summary = `Sessão - ${params.title}`
  if (params.description || params.type) {
    patch.description = `${params.type ?? ''} - Terapô.pro${params.description ? '\n' + params.description : ''}`
  }
  if (params.date && params.time) {
    patch.start = { dateTime: toDateTimeLocal(params.date, params.time), timeZone: 'America/Sao_Paulo' }
    if (params.duration) {
      patch.end = { dateTime: addMinutes(params.date, params.time, params.duration), timeZone: 'America/Sao_Paulo' }
    }
  }

  const response = await fetch(
    `https://www.googleapis.com/calendar/v3/calendars/primary/events/${eventId}`,
    {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(patch),
    }
  )

  if (!response.ok) {
    throw new Error(`Google Calendar API error: ${response.status}`)
  }
}
