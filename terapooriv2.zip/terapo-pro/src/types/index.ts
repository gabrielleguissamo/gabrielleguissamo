export interface Profile {
  id: string
  full_name: string
  email: string
  crf_to?: string
  city?: string
  state?: string
  plan: 'inicial' | 'profissional' | 'business'
  avatar_url?: string
  created_at: string
}

export interface Patient {
  id: string
  user_id: string
  name: string
  birth_date: string
  cpf?: string
  diagnosis?: string
  guardian_name?: string
  phone?: string
  email?: string
  insurance?: string
  status: 'ativo' | 'em_espera' | 'inativo'
  created_at: string
}

export interface AppSession {
  id: string
  user_id: string
  patient_id: string
  date: string
  time: string
  duration: 30 | 45 | 60 | 90
  type: 'domiciliar' | 'online' | 'escola' | 'presencial'
  status: 'confirmado' | 'pendente' | 'cancelado'
  notes?: string
  google_event_id?: string | null
  created_at: string
}

export interface MedicalRecord {
  id: string
  patient_id: string
  session_id?: string
  date: string
  content: string
  assessment_type?: string
  created_at: string
}

export interface Transaction {
  id: string
  user_id: string
  patient_id?: string
  date: string
  amount: number
  type: 'sessao' | 'avaliacao' | 'material'
  payment_method?: string
  status: 'pago' | 'pendente' | 'cancelado'
  created_at: string
}
