import React, { useState, useEffect } from 'react'
import { Plus, ChevronLeft, ChevronRight, X } from 'lucide-react'
import { Card } from '../../components/ui/Card'
import { Button } from '../../components/ui/Button'
import { Toast } from '../../components/ui/Toast'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import type { AppSession, Patient } from '../../types'
import {
  requestGoogleCalendarAccess,
  createGoogleCalendarEvent,
  deleteGoogleCalendarEvent,
  getAccessToken,
} from '../../lib/googleCalendar'

const DAYS = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom']
const HOURS = Array.from({ length: 14 }, (_, i) => `${String(i + 7).padStart(2, '0')}:00`)

const statusColors = {
  confirmado: 'bg-green-100 text-green-700 border-l-2 border-green-500',
  pendente: 'bg-yellow-50 text-yellow-700 border-l-2 border-yellow-400',
  cancelado: 'bg-gray-100 text-gray-500 border-l-2 border-gray-300 line-through',
}

type SessionWithPatient = AppSession & { patients?: { name: string } }

function getWeekStart(date: Date): Date {
  const d = new Date(date)
  const day = d.getDay()
  // Monday = 0
  const diff = (day === 0 ? -6 : 1 - day)
  d.setDate(d.getDate() + diff)
  d.setHours(0, 0, 0, 0)
  return d
}

function addDays(date: Date, days: number): Date {
  const d = new Date(date)
  d.setDate(d.getDate() + days)
  return d
}

function toISO(date: Date): string {
  return date.toISOString().slice(0, 10)
}

export function Agenda() {
  const { user } = useAuth()
  const [sessions, setSessions] = useState<SessionWithPatient[]>([])
  const [patients, setPatients] = useState<Patient[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [saving, setSaving] = useState(false)
  const [view, setView] = useState<'semana' | 'dia' | 'mes'>('semana')
  const [weekStart, setWeekStart] = useState(() => getWeekStart(new Date()))
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)
  const [googleConnected, setGoogleConnected] = useState(false)

  const [form, setForm] = useState({
    patient_id: '', date: '', time: '', duration: '60',
    type: 'presencial' as AppSession['type'], notes: '',
  })

  async function fetchSessions() {
    if (!user) return
    setLoading(true)
    const { data, error } = await supabase
      .from('sessions')
      .select('*, patients(name), google_event_id')
      .eq('user_id', user.id)
    if (error) {
      setToast({ message: 'Erro ao carregar sessões', type: 'error' })
    } else {
      setSessions((data ?? []) as SessionWithPatient[])
    }
    setLoading(false)
  }

  async function fetchPatients() {
    if (!user) return
    const { data } = await supabase
      .from('patients')
      .select('id, name, status')
      .eq('user_id', user.id)
      .eq('status', 'ativo')
      .order('name', { ascending: true })
    if (data) setPatients(data as Patient[])
  }

  useEffect(() => { fetchSessions(); fetchPatients() }, [user])

  async function handleConnectGoogle() {
    try {
      await requestGoogleCalendarAccess()
      setGoogleConnected(true)
      setToast({ message: 'Google Agenda conectado!', type: 'success' })
    } catch {
      setToast({ message: 'Erro ao conectar Google Agenda', type: 'error' })
    }
  }

  async function handleSave() {
    if (!user || !form.patient_id || !form.date || !form.time) return
    setSaving(true)

    const { data: inserted, error } = await supabase.from('sessions').insert({
      user_id: user.id,
      patient_id: form.patient_id,
      date: form.date,
      time: form.time,
      duration: parseInt(form.duration) as AppSession['duration'],
      type: form.type,
      status: 'pendente',
      notes: form.notes || null,
    }).select('id').single()

    if (error) {
      setSaving(false)
      setToast({ message: 'Erro ao salvar sessão', type: 'error' })
      return
    }

    // Sync to Google Calendar if connected
    if (getAccessToken() && inserted) {
      try {
        const patient = patients.find(p => p.id === form.patient_id)
        const googleEventId = await createGoogleCalendarEvent({
          title: patient?.name ?? 'Paciente',
          date: form.date,
          time: form.time,
          duration: parseInt(form.duration),
          description: form.notes || undefined,
          type: form.type,
        })
        // Store google_event_id in the session record
        await supabase.from('sessions').update({ google_event_id: googleEventId }).eq('id', inserted.id)
        setToast({ message: 'Sessão salva e adicionada ao Google Agenda!', type: 'success' })
      } catch {
        setToast({ message: 'Sessão salva! (Erro ao sincronizar Google Agenda)', type: 'success' })
      }
    } else {
      setToast({ message: 'Sessão salva!', type: 'success' })
    }

    setSaving(false)
    setShowModal(false)
    setForm({ patient_id: '', date: '', time: '', duration: '60', type: 'presencial', notes: '' })
    fetchSessions()
  }

  async function toggleStatus(session: SessionWithPatient) {
    const nextStatus: Record<AppSession['status'], AppSession['status']> = {
      pendente: 'confirmado',
      confirmado: 'cancelado',
      cancelado: 'pendente',
    }
    const newStatus = nextStatus[session.status]
    const { error } = await supabase
      .from('sessions')
      .update({ status: newStatus })
      .eq('id', session.id)
    if (error) {
      setToast({ message: 'Erro ao atualizar status', type: 'error' })
    } else {
      setSessions(prev => prev.map(s => s.id === session.id ? { ...s, status: newStatus } : s))
      // If cancelling and has a Google event, delete it
      if (newStatus === 'cancelado' && session.google_event_id && getAccessToken()) {
        try {
          await deleteGoogleCalendarEvent(session.google_event_id)
        } catch {
          // Silently ignore Google sync errors
        }
      }
    }
  }

  const weekDates = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i))

  function formatWeekLabel() {
    const start = weekDates[0]
    const end = weekDates[6]
    const startStr = start.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long' })
    const endStr = end.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long' })
    return `${startStr} a ${endStr}`
  }

  function getSessionForCell(dayIndex: number, hour: string): SessionWithPatient | undefined {
    const dateStr = toISO(weekDates[dayIndex])
    return sessions.find(s => s.date === dateStr && s.time.slice(0, 5) === hour)
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl p-1">
          {(['dia', 'semana', 'mes'] as const).map(v => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${view === v ? 'bg-green-500 text-white' : 'text-ink-4 hover:text-ink'}`}
            >
              {v.charAt(0).toUpperCase() + v.slice(1)}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          {googleConnected ? (
            <span className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm font-medium">
              Google Agenda conectado ✓
            </span>
          ) : (
            <Button variant="outline" onClick={handleConnectGoogle}>
              Conectar Google Agenda
            </Button>
          )}
          <Button onClick={() => setShowModal(true)}>
            <Plus className="w-4 h-4" /> Nova sessão
          </Button>
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b">
          <button className="p-1 text-ink-4 hover:text-ink" onClick={() => setWeekStart(w => addDays(w, -7))}>
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="font-medium text-ink">{formatWeekLabel()}</span>
          <button className="p-1 text-ink-4 hover:text-ink" onClick={() => setWeekStart(w => addDays(w, 7))}>
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
        {loading ? (
          <div className="flex items-center justify-center h-40">
            <div className="w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-auto">
            <div className="grid" style={{ gridTemplateColumns: '60px repeat(7, 1fr)', minWidth: '700px' }}>
              <div className="border-b border-r h-10" />
              {DAYS.map((d, i) => (
                <div key={d} className="border-b border-r h-10 flex flex-col items-center justify-center text-sm font-medium text-ink-3">
                  <span>{d}</span>
                  <span className="text-xs text-ink-5">{weekDates[i].getDate()}</span>
                </div>
              ))}
              {HOURS.map(hour => (
                <React.Fragment key={hour}>
                  <div className="border-b border-r px-2 py-1 text-xs text-ink-5">{hour}</div>
                  {DAYS.map((_, dayIdx) => {
                    const session = getSessionForCell(dayIdx, hour)
                    return (
                      <div key={dayIdx} className="border-b border-r h-12 p-1 relative">
                        {session && (
                          <button
                            className={`w-full text-xs rounded px-1 py-0.5 truncate text-left ${statusColors[session.status]}`}
                            onClick={() => toggleStatus(session)}
                            title="Clique para mudar status"
                          >
                            {session.patients?.name ?? 'Paciente'}
                          </button>
                        )}
                      </div>
                    )
                  })}
                </React.Fragment>
              ))}
            </div>
          </div>
        )}
      </Card>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-serif text-lg font-semibold">Nova sessão</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5 text-ink-4" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Paciente</label>
                <select
                  className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                  value={form.patient_id}
                  onChange={e => setForm(f => ({ ...f, patient_id: e.target.value }))}
                >
                  <option value="">Selecione...</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Data</label>
                  <input
                    type="date"
                    className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                    value={form.date}
                    onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-ink-2 block mb-1">Horário</label>
                  <input
                    type="time"
                    className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                    value={form.time}
                    onChange={e => setForm(f => ({ ...f, time: e.target.value }))}
                  />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Duração</label>
                <select
                  className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                  value={form.duration}
                  onChange={e => setForm(f => ({ ...f, duration: e.target.value }))}
                >
                  <option value="30">30 min</option>
                  <option value="45">45 min</option>
                  <option value="60">60 min</option>
                  <option value="90">90 min</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Tipo</label>
                <select
                  className="w-full h-12 px-4 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500"
                  value={form.type}
                  onChange={e => setForm(f => ({ ...f, type: e.target.value as AppSession['type'] }))}
                >
                  <option value="presencial">Presencial</option>
                  <option value="online">Online</option>
                  <option value="domiciliar">Domiciliar</option>
                  <option value="escola">Escola</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-ink-2 block mb-1">Observações</label>
                <textarea
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-green-500 resize-none h-20"
                  value={form.notes}
                  onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                />
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" fullWidth onClick={() => setShowModal(false)}>Cancelar</Button>
                <Button fullWidth onClick={handleSave} disabled={saving || !form.patient_id || !form.date || !form.time}>
                  {saving ? 'Salvando...' : 'Salvar'}
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  )
}
